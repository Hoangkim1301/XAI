Setup instructions:
1. Install Anaconda and setup conda: https://conda.io/projects/conda/en/latest/user-guide/getting-started.html
2. cd to the practical-exercise folder.
3. Create environment: execute command "conda env create -f enviroment.yml" (without the double quotes)
4. Activate environment: execute command "conda activate xai" (without the double quotes)
5. Run jupyter-lab: execute command "jupyter-lab" (without the double quotes)